package com.cap.dao;

import com.cap.bean.LoginBean;

public interface ILoginDao {
	public boolean isValidLogin(LoginBean loginBean);
	
}
