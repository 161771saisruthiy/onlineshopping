package com.cap.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cap.bean.LoginBean;




public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		String sql="select * from userlogin where username=? and userpsswd=?";
		try(PreparedStatement ps=getConnection().prepareStatement(sql);){
			ps.setString(1,loginBean.getUserName());
			ps.setString(2,loginBean.getPassword());
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				return true;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	private Connection getConnection() {
		Connection connection=null;
	
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/javatr6","root","India123");
				return connection;
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return connection;
			
		
	}


}
