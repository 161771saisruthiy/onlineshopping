package com.cap.service;

import com.cap.bean.LoginBean;

public interface ILoginService {
	public boolean isValidLogin(LoginBean loginBean);
	

}
