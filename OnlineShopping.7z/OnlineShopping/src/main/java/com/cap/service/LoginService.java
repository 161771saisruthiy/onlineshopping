package com.cap.service;

import com.cap.bean.LoginBean;

import com.cap.dao.ILoginDao;
import com.cap.dao.LoginDaoImpl;

public class LoginService implements ILoginService{
	private ILoginDao loginDao;
	public LoginService() {
		this.loginDao=new LoginDaoImpl();
	}

	@Override
	public boolean isValidLogin(LoginBean loginBean) {
		if(loginDao.isValidLogin(loginBean)) {
			return true;
		}
		return false;
	}

	
}
