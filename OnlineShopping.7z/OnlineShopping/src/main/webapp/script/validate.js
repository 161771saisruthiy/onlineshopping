function validate(){
	var flag=false;
	var username=f1.username.value;
	var password=f1.password.value;

	if(username==""||username==null){
		//document.getElementById().inneerHTML="Please enter username";
		alert("Please enter username");
		flag=false;
	}else if(password==null||password==""){
		//document.getElementById().inneerHTML="Please enter password";
		alert("Please enter password");
		flag=false;
	}else{
		flag=true;
	}
	
}